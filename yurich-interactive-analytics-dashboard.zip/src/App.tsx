import { useEffect, useMemo, useState } from "react";
import Topbar from "./components/Topbar";
import Sidebar from "./components/Sidebar";
import FiltersBar from "./components/FiltersBar";
import KpiCards from "./components/KpiCards";
import TrafficChart from "./components/TrafficChart";
import SourcesDonut from "./components/SourcesDonut";
import ContentBar from "./components/ContentBar";
import DataTable from "./components/DataTable";
import { Reveal } from "./components/ui";
import {
  getKpis,
  getRangeLabel,
  getRows,
  getSeries,
  getSources,
  getTopPages,
  RANGES,
  type RangeKey,
  type SegmentKey,
} from "./lib/data";

export default function App() {
  const [dark, setDark] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem("yha-theme");
      if (saved) return saved === "dark";
      return window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? false;
    } catch {
      return false;
    }
  });

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    document.documentElement.style.colorScheme = dark ? "dark" : "light";
    try {
      localStorage.setItem("yha-theme", dark ? "dark" : "light");
    } catch {
      /* noop */
    }
  }, [dark]);

  const [range, setRange] = useState<RangeKey>("30d");
  const [segment, setSegment] = useState<SegmentKey>("all");
  const [navOpen, setNavOpen] = useState(false);

  // every view derives from the same two filters → all views update live
  const kpis = useMemo(() => getKpis(range, segment), [range, segment]);
  const series = useMemo(() => getSeries(range, segment), [range, segment]);
  const sources = useMemo(() => getSources(range, segment), [range, segment]);
  const rows = useMemo(() => getRows(range, segment), [range, segment]);
  const topPages = useMemo(() => getTopPages(range, segment, 6), [range, segment]);

  const rangeLabel = getRangeLabel(range);
  const rangeDays = RANGES.find((r) => r.key === range)!.days;

  const resetFilters = () => {
    setRange("30d");
    setSegment("all");
  };

  return (
    <div id="top" className="min-h-screen">
      {/* ambient background */}
      <div aria-hidden className="pointer-events-none fixed inset-0 -z-10">
        <div className="bg-grid absolute inset-0" />
        <div className="absolute -top-36 left-1/4 h-96 w-[34rem] rounded-full bg-indigo-500/[0.12] blur-[120px] dark:bg-indigo-500/[0.15]" />
        <div className="absolute top-52 -right-32 h-80 w-80 rounded-full bg-cyan-400/[0.1] blur-[110px] dark:bg-cyan-400/[0.12]" />
        <div className="absolute bottom-0 left-0 h-72 w-72 rounded-full bg-violet-400/[0.07] blur-[110px] dark:bg-violet-500/[0.1]" />
      </div>

      <Sidebar segment={segment} onSegment={setSegment} mobileOpen={navOpen} onCloseMobile={() => setNavOpen(false)} />

      <div className="lg:pl-[248px]">
        <Topbar
          dark={dark}
          onToggleDark={() => setDark((d) => !d)}
          onOpenNav={() => setNavOpen(true)}
          segment={segment}
          onResetFilters={resetFilters}
        />

        <main className="mx-auto max-w-[1480px] px-4 py-6 sm:px-6 sm:py-8">
          {/* page header + live filters */}
          <div className="mb-6 flex flex-wrap items-end justify-between gap-x-6 gap-y-4">
            <div className="min-w-0">
              <p className="text-[11px] font-bold tracking-[0.22em] text-indigo-500 uppercase dark:text-indigo-400">
                YurichHub · Overview
              </p>
              <h1 className="mt-1.5 font-display text-[26px] leading-tight font-bold tracking-tight text-zinc-900 sm:text-3xl dark:text-white">
                Hub performance
              </h1>
              <p className="mt-1 max-w-xl text-[13px] text-zinc-500 dark:text-zinc-400">
                Traffic, conversion and content across Sevastopol AI, City Code, Crimea RWA and the YuRich RWA course.
              </p>
            </div>
            <FiltersBar range={range} onRange={setRange} segment={segment} onSegment={setSegment} rangeLabel={rangeLabel} />
          </div>

          {/* KPI cards */}
          <div id="kpis" className="scroll-mt-24">
            <KpiCards kpis={kpis} prevDays={rangeDays} />
          </div>

          {/* line + donut */}
          <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-3">
            <Reveal className="xl:col-span-2" delay={0.04}>
              <TrafficChart data={series} dark={dark} range={range} rangeLabel={rangeLabel} />
            </Reveal>
            <Reveal delay={0.08}>
              <SourcesDonut data={sources} dark={dark} segment={segment} />
            </Reveal>
          </div>

          {/* bar + table */}
          <div className="mt-4 grid grid-cols-1 items-start gap-4 xl:grid-cols-3">
            <Reveal delay={0.04}>
              <ContentBar rows={topPages} dark={dark} />
            </Reveal>
            <Reveal className="xl:col-span-2" delay={0.08}>
              <DataTable rows={rows} segment={segment} range={range} />
            </Reveal>
          </div>

          <footer className="mt-10 flex flex-wrap items-center justify-between gap-2 border-t border-zinc-200/70 pt-5 pb-2 text-[11px] text-zinc-400 dark:border-white/[0.06] dark:text-zinc-500">
            <p>
              YurichHub Analytics — sample data generated locally · deterministic seed ·{" "}
              <span className="font-medium text-zinc-500 dark:text-zinc-400">every filter updates every view live</span>
            </p>
            <p className="tnum font-mono">44.6167° N · 33.5258° E · Sevastopol</p>
          </footer>
        </main>
      </div>
    </div>
  );
}
