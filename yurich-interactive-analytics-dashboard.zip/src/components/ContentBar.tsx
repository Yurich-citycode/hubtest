import { useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  LabelList,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { motion } from "framer-motion";
import { cn } from "../utils/cn";
import { Card, CardHeader, TooltipShell } from "./ui";
import { fmtCompact, fmtDur, fmtFull, fmtPct, type TableRow } from "../lib/data";

type Metric = "views" | "conv";

const truncate = (t: string) => (t.length > 24 ? `${t.slice(0, 23)}…` : t);

function Tip({ active, payload }: any) {
  if (!active || !payload?.length) return null;
  const r = payload[0].payload as TableRow;
  return (
    <TooltipShell
      title={r.title}
      rows={[
        { dot: "#6366F1", label: "Views", value: fmtFull(r.views) },
        { dot: "#22D3EE", label: "Uniques", value: fmtFull(r.uniques) },
        { dot: "#FBBF24", label: "Conversions", value: fmtFull(r.conv) },
        { dot: "#94A3B8", label: "Conv. rate", value: fmtPct(r.convRate) },
        { dot: "#FB7185", label: "Bounce", value: fmtPct(r.bounce, 1) },
        { dot: "#A78BFA", label: "Avg. time", value: fmtDur(r.avgTime) },
      ]}
    />
  );
}

export default function ContentBar({ rows, dark }: { rows: TableRow[]; dark: boolean }) {
  const [metric, setMetric] = useState<Metric>("views");

  const data = [...rows].sort((a, b) => a[metric] - b[metric]); // recharts draws bottom-up
  const grid = dark ? "rgba(148,163,184,0.09)" : "#E7EAF1";
  const tick = dark ? "#8B94A5" : "#5B6472";

  return (
    <Card id="content" className="flex h-full flex-col p-5 sm:p-6">
      <CardHeader
        title="Top content"
        sub="Best performing pages of the hub"
        right={
          <div className="flex items-center rounded-lg border border-zinc-200 bg-zinc-50 p-0.5 dark:border-white/10 dark:bg-white/[0.04]">
            {(["views", "conv"] as Metric[]).map((m) => {
              const on = metric === m;
              return (
                <button
                  key={m}
                  onClick={() => setMetric(m)}
                  className={cn(
                    "focusable relative rounded-md px-2.5 py-1 text-[11px] font-semibold transition-colors",
                    on ? "text-zinc-900 dark:text-white" : "text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300",
                  )}
                >
                  {on && (
                    <motion.span
                      layoutId="bar-metric"
                      className="absolute inset-0 rounded-md bg-white shadow-sm ring-1 ring-zinc-200 dark:bg-white/10 dark:ring-white/10"
                      transition={{ type: "spring", damping: 32, stiffness: 420 }}
                    />
                  )}
                  <span className="relative z-10">{m === "views" ? "Views" : "Conv."}</span>
                </button>
              );
            })}
          </div>
        }
      />

      <div className="mt-4 min-h-[260px] w-full flex-1">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} layout="vertical" margin={{ top: 2, right: 42, bottom: 0, left: 0 }} barCategoryGap={10}>
            <defs>
              <linearGradient id="bg-views" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor={dark ? "#818CF8" : "#6366F1"} />
                <stop offset="100%" stopColor={dark ? "#22D3EE" : "#06B6D4"} />
              </linearGradient>
              <linearGradient id="bg-conv" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor={dark ? "#FBBF24" : "#F59E0B"} />
                <stop offset="100%" stopColor={dark ? "#FB7185" : "#F43F5E"} />
              </linearGradient>
            </defs>
            <CartesianGrid horizontal={false} stroke={grid} strokeDasharray="3 6" />
            <XAxis
              type="number"
              tickFormatter={(v: number) => fmtCompact(v)}
              tickLine={false}
              axisLine={false}
              tick={{ fill: tick, fontSize: 11 }}
              width={36}
            />
            <YAxis
              type="category"
              dataKey="title"
              tickFormatter={truncate}
              tickLine={false}
              axisLine={false}
              tick={{ fill: tick, fontSize: 11 }}
              width={158}
            />
            <Tooltip content={<Tip />} cursor={{ fill: dark ? "rgba(148,163,184,0.07)" : "rgba(99,102,241,0.05)" }} />
            <Bar
              dataKey={metric}
              fill={`url(#bg-${metric})`}
              radius={[0, 7, 7, 0]}
              barSize={16}
              isAnimationActive
              animationDuration={700}
              animationEasing="ease-out"
            >
              <LabelList
                dataKey={metric}
                position="right"
                formatter={(v: unknown) => fmtCompact(Number(v ?? 0))}
                style={{ fill: tick, fontSize: 11, fontFamily: "'JetBrains Mono', monospace", fontWeight: 600 }}
              />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}
