import { useEffect, useMemo, useState } from "react";
import {
  ArrowDown,
  ArrowUp,
  ChevronLeft,
  ChevronRight,
  ChevronsUpDown,
  Download,
  Search,
  SearchX,
} from "lucide-react";
import { cn } from "../utils/cn";
import { Card, CardHeader, DeltaBadge, Spark } from "./ui";
import {
  fmtDur,
  fmtFull,
  fmtPct,
  SECTION_MAP,
  type RangeKey,
  type SegmentKey,
  type TableRow,
} from "../lib/data";

type SortKey = "views" | "uniques" | "conv" | "convRate" | "bounce" | "avgTime" | "delta";
type SortDir = "asc" | "desc";

const PAGE_SIZE = 8;

interface Col {
  key: SortKey;
  label: string;
  hide?: string;
}

const COLS: Col[] = [
  { key: "views", label: "Views" },
  { key: "uniques", label: "Uniques", hide: "hidden lg:table-cell" },
  { key: "conv", label: "Conv." },
  { key: "convRate", label: "Rate", hide: "hidden lg:table-cell" },
  { key: "bounce", label: "Bounce", hide: "hidden md:table-cell" },
  { key: "avgTime", label: "Avg. time", hide: "hidden xl:table-cell" },
  { key: "delta", label: "Trend" },
];

function exportCsv(rows: TableRow[], range: RangeKey, segment: SegmentKey) {
  const head = "Page,Path,Section,Views,Uniques,Conversions,ConvRate,Bounce,AvgTimeSec,TrendPct";
  const lines = rows.map((r) =>
    [
      `"${r.title.replace(/"/g, '""')}"`,
      r.path,
      SECTION_MAP[r.section].label,
      r.views,
      r.uniques,
      r.conv,
      (r.convRate * 100).toFixed(2) + "%",
      (r.bounce * 100).toFixed(1) + "%",
      r.avgTime,
      (r.delta * 100).toFixed(1) + "%",
    ].join(","),
  );
  const blob = new Blob([head + "\n" + lines.join("\n")], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `yurichhub-pages-${range}-${segment}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export default function DataTable({
  rows,
  segment,
  range,
}: {
  rows: TableRow[];
  segment: SegmentKey;
  range: RangeKey;
}) {
  const [search, setSearch] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("views");
  const [sortDir, setSortDir] = useState<SortDir>("desc");
  const [page, setPage] = useState(0);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const base = q
      ? rows.filter((r) => r.title.toLowerCase().includes(q) || r.path.toLowerCase().includes(q))
      : [...rows];
    base.sort((a, b) => {
      const d = a[sortKey] - b[sortKey];
      return sortDir === "asc" ? d : -d;
    });
    return base;
  }, [rows, search, sortKey, sortDir]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  useEffect(() => setPage(0), [search, segment, range]);
  useEffect(() => {
    if (page > pageCount - 1) setPage(pageCount - 1);
  }, [page, pageCount]);

  const visible = filtered.slice(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE);

  const toggleSort = (key: SortKey) => {
    if (key === sortKey) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortKey(key);
      setSortDir("desc");
    }
  };

  return (
    <Card id="pages" className="flex h-full flex-col p-5 sm:p-6">
      <CardHeader
        title="Pages"
        sub={`${filtered.length} tracked pages · ${SECTION_MAP[segment].label}`}
        right={
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 rounded-xl border border-zinc-200 bg-white px-3 py-2 transition-all focus-within:border-indigo-400 focus-within:ring-4 focus-within:ring-indigo-500/10 dark:border-white/10 dark:bg-white/[0.04] dark:focus-within:border-indigo-400/60">
              <Search className="h-3.5 w-3.5 shrink-0 text-zinc-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Filter pages…"
                className="w-28 bg-transparent text-xs text-zinc-700 outline-none placeholder:text-zinc-400 sm:w-36 dark:text-zinc-200 dark:placeholder:text-zinc-500"
              />
            </div>
            <button
              onClick={() => exportCsv(filtered, range, segment)}
              title="Export filtered rows as CSV"
              className="focusable grid h-[34px] w-[34px] place-items-center rounded-xl border border-zinc-200 bg-white text-zinc-500 transition-colors hover:border-indigo-300 hover:text-indigo-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-400 dark:hover:border-indigo-400/40 dark:hover:text-indigo-300"
            >
              <Download className="h-4 w-4" />
            </button>
          </div>
        }
      />

      <div className="mt-4 -mx-5 flex-1 overflow-x-auto px-5 sm:-mx-6 sm:px-6">
        <table className="w-full min-w-[720px] border-separate border-spacing-0 text-left">
          <thead>
            <tr>
              <th className="border-b border-zinc-200 pb-2.5 pl-1 text-[10px] font-bold tracking-[0.14em] text-zinc-400 uppercase dark:border-white/[0.08] dark:text-zinc-500">
                Page
              </th>
              <th className="hidden border-b border-zinc-200 pb-2.5 text-[10px] font-bold tracking-[0.14em] text-zinc-400 uppercase md:table-cell dark:border-white/[0.08] dark:text-zinc-500">
                Section
              </th>
              {COLS.map((c) => {
                const active = sortKey === c.key;
                const Icon = active ? (sortDir === "asc" ? ArrowUp : ArrowDown) : ChevronsUpDown;
                return (
                  <th
                    key={c.key}
                    className={cn(
                      "border-b border-zinc-200 pb-2.5 pl-3 text-right dark:border-white/[0.08]",
                      c.hide,
                    )}
                  >
                    <button
                      onClick={() => toggleSort(c.key)}
                      className={cn(
                        "focusable inline-flex items-center gap-1 rounded text-[10px] font-bold tracking-[0.14em] uppercase transition-colors",
                        active ? "text-indigo-600 dark:text-indigo-400" : "text-zinc-400 hover:text-zinc-600 dark:text-zinc-500 dark:hover:text-zinc-300",
                      )}
                    >
                      {c.label}
                      <Icon className={cn("h-3 w-3", !active && "opacity-50")} strokeWidth={2.5} />
                    </button>
                  </th>
                );
              })}
              <th className="hidden w-[110px] border-b border-zinc-200 pb-2.5 pl-3 text-right text-[10px] font-bold tracking-[0.14em] text-zinc-400 uppercase xl:table-cell dark:border-white/[0.08] dark:text-zinc-500">
                Trend line
              </th>
            </tr>
          </thead>
          <tbody>
            {visible.map((r) => {
              const sec = SECTION_MAP[r.section];
              return (
                <tr
                  key={r.id}
                  className="group transition-colors hover:bg-indigo-500/[0.03] dark:hover:bg-white/[0.028]"
                >
                  <td className="max-w-[220px] border-b border-zinc-100 py-3 pr-3 pl-1 dark:border-white/[0.05]">
                    <p className="truncate text-[13px] font-semibold text-zinc-800 dark:text-zinc-100">{r.title}</p>
                    <p className="mt-0.5 truncate font-mono text-[11px] text-zinc-400 dark:text-zinc-500">{r.path}</p>
                  </td>
                  <td className="hidden border-b border-zinc-100 py-3 pr-2 whitespace-nowrap md:table-cell dark:border-white/[0.05]">
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-zinc-900/[0.04] px-2 py-1 text-[11px] font-medium text-zinc-600 dark:bg-white/[0.06] dark:text-zinc-300">
                      <span className="h-1.5 w-1.5 rounded-full" style={{ background: sec.color }} />
                      {sec.label}
                    </span>
                  </td>
                  <td className="tnum border-b border-zinc-100 py-3 pl-3 text-right font-mono text-[13px] font-semibold text-zinc-900 dark:border-white/[0.05] dark:text-zinc-50">
                    {fmtFull(r.views)}
                  </td>
                  <td className="tnum hidden border-b border-zinc-100 py-3 pl-3 text-right font-mono text-xs text-zinc-500 lg:table-cell dark:border-white/[0.05] dark:text-zinc-400">
                    {fmtFull(r.uniques)}
                  </td>
                  <td className="tnum border-b border-zinc-100 py-3 pl-3 text-right font-mono text-xs text-zinc-600 dark:border-white/[0.05] dark:text-zinc-300">
                    {fmtFull(r.conv)}
                  </td>
                  <td className="tnum hidden border-b border-zinc-100 py-3 pl-3 text-right font-mono text-xs text-zinc-500 lg:table-cell dark:border-white/[0.05] dark:text-zinc-400">
                    {fmtPct(r.convRate)}
                  </td>
                  <td className="tnum hidden border-b border-zinc-100 py-3 pl-3 text-right font-mono text-xs text-zinc-500 md:table-cell dark:border-white/[0.05] dark:text-zinc-400">
                    {fmtPct(r.bounce, 1)}
                  </td>
                  <td className="tnum hidden border-b border-zinc-100 py-3 pl-3 text-right font-mono text-xs text-zinc-500 xl:table-cell dark:border-white/[0.05] dark:text-zinc-400">
                    {fmtDur(r.avgTime)}
                  </td>
                  <td className="border-b border-zinc-100 py-3 pl-3 text-right dark:border-white/[0.05]">
                    <DeltaBadge delta={r.delta} />
                  </td>
                  <td className="hidden border-b border-zinc-100 py-3 pl-3 xl:table-cell dark:border-white/[0.05]">
                    <Spark
                      data={r.spark}
                      color={r.delta >= 0 ? "#10B981" : "#F43F5E"}
                      height={26}
                      strokeWidth={1.6}
                      className="ml-auto w-[96px]"
                    />
                  </td>
                </tr>
              );
            })}

            {visible.length === 0 && (
              <tr>
                <td colSpan={10} className="py-14 text-center">
                  <SearchX className="mx-auto h-6 w-6 text-zinc-300 dark:text-zinc-600" />
                  <p className="mt-3 text-sm font-semibold text-zinc-500 dark:text-zinc-400">
                    No pages match “{search}”
                  </p>
                  <p className="mt-1 text-xs text-zinc-400 dark:text-zinc-500">Try a different keyword or clear the filter.</p>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* pagination */}
      <div className="mt-4 flex items-center justify-between gap-3 border-t border-zinc-100 pt-4 dark:border-white/[0.06]">
        <p className="tnum text-[11px] text-zinc-400 dark:text-zinc-500">
          Showing{" "}
          <span className="font-semibold text-zinc-600 dark:text-zinc-300">
            {filtered.length === 0 ? 0 : page * PAGE_SIZE + 1}–{Math.min(filtered.length, (page + 1) * PAGE_SIZE)}
          </span>{" "}
          of {filtered.length}
        </p>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setPage((p) => Math.max(0, p - 1))}
            disabled={page === 0}
            aria-label="Previous page"
            className="focusable grid h-8 w-8 place-items-center rounded-lg border border-zinc-200 bg-white text-zinc-500 transition-all enabled:hover:border-indigo-300 enabled:hover:text-indigo-600 disabled:opacity-35 dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-400 dark:enabled:hover:border-indigo-400/40 dark:enabled:hover:text-indigo-300"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <span className="tnum px-1.5 font-mono text-[11px] font-semibold text-zinc-500 dark:text-zinc-400">
            {page + 1} / {pageCount}
          </span>
          <button
            onClick={() => setPage((p) => Math.min(pageCount - 1, p + 1))}
            disabled={page >= pageCount - 1}
            aria-label="Next page"
            className="focusable grid h-8 w-8 place-items-center rounded-lg border border-zinc-200 bg-white text-zinc-500 transition-all enabled:hover:border-indigo-300 enabled:hover:text-indigo-600 disabled:opacity-35 dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-400 dark:enabled:hover:border-indigo-400/40 dark:enabled:hover:text-indigo-300"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </Card>
  );
}
