import { Eye, Percent, Timer, Users, type LucideIcon } from "lucide-react";
import { cn } from "../utils/cn";
import { Card, DeltaBadge, Reveal, Spark } from "./ui";
import { useCountUp } from "../lib/hooks";
import { fmtKpiValue, type Kpi } from "../lib/data";

const META: Record<Kpi["id"], { icon: LucideIcon; tint: string; chip: string; spark: string }> = {
  visitors: {
    icon: Users,
    chip: "bg-indigo-500/10 text-indigo-600 ring-indigo-500/20 dark:text-indigo-300",
    tint: "group-hover:shadow-[0_8px_30px_-12px_rgba(99,102,241,0.55)]",
    spark: "#6366F1",
  },
  pageviews: {
    icon: Eye,
    chip: "bg-cyan-500/10 text-cyan-600 ring-cyan-500/20 dark:text-cyan-300",
    tint: "group-hover:shadow-[0_8px_30px_-12px_rgba(34,211,238,0.55)]",
    spark: "#22D3EE",
  },
  conversion: {
    icon: Percent,
    chip: "bg-amber-500/10 text-amber-600 ring-amber-500/20 dark:text-amber-300",
    tint: "group-hover:shadow-[0_8px_30px_-12px_rgba(251,191,36,0.5)]",
    spark: "#FBBF24",
  },
  avgsession: {
    icon: Timer,
    chip: "bg-violet-500/10 text-violet-600 ring-violet-500/20 dark:text-violet-300",
    tint: "group-hover:shadow-[0_8px_30px_-12px_rgba(167,139,250,0.55)]",
    spark: "#A78BFA",
  },
};

function KpiCard({ kpi, prevLabel }: { kpi: Kpi; prevLabel: string }) {
  const meta = META[kpi.id];
  const Icon = meta.icon;
  const display = useCountUp(kpi.value);

  return (
    <Card
      className={cn(
        "group p-5 transition-all duration-300 hover:-translate-y-0.5 hover:border-zinc-300/80 dark:hover:border-white/[0.14]",
        meta.tint,
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <span className={cn("grid h-9 w-9 place-items-center rounded-xl ring-1", meta.chip)}>
          <Icon className="h-[17px] w-[17px]" strokeWidth={2.2} />
        </span>
        <DeltaBadge delta={kpi.delta} />
      </div>

      <div className="mt-4 flex items-end justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-xs font-medium text-zinc-500 dark:text-zinc-400">{kpi.label}</p>
          <p className="tnum mt-1 font-display text-[26px] leading-none font-bold tracking-tight text-zinc-900 sm:text-[28px] dark:text-white">
            {fmtKpiValue(display, kpi.format)}
          </p>
          <p className="mt-2 text-[11px] text-zinc-400 dark:text-zinc-500">vs. previous {prevLabel}</p>
        </div>
        <Spark data={kpi.spark} color={meta.spark} height={44} strokeWidth={2.2} className="w-[42%] max-w-[128px] shrink-0" />
      </div>
    </Card>
  );
}

export default function KpiCards({ kpis, prevDays }: { kpis: Kpi[]; prevDays: number }) {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {kpis.map((kpi, i) => (
        <Reveal key={kpi.id} delay={i * 0.06}>
          <KpiCard kpi={kpi} prevLabel={`${prevDays} days`} />
        </Reveal>
      ))}
    </div>
  );
}
