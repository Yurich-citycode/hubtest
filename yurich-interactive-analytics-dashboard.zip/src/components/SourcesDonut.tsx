import { useState } from "react";
import { Cell, Pie, PieChart, ResponsiveContainer } from "recharts";
import { cn } from "../utils/cn";
import { Card, CardHeader } from "./ui";
import { fmtCompact, fmtFull, fmtPct, type SegmentKey } from "../lib/data";
import { SECTION_MAP, type SourceDatum } from "../lib/data";

export default function SourcesDonut({
  data,
  dark,
  segment,
}: {
  data: SourceDatum[];
  dark: boolean;
  segment: SegmentKey;
}) {
  const [active, setActive] = useState<number | null>(null);
  const total = data.reduce((a, s) => a + s.value, 0);
  const current = active !== null ? data[active] : null;

  return (
    <Card id="sources" className="flex h-full flex-col p-5 sm:p-6">
      <CardHeader
        title="Traffic sources"
        sub={`Where ${SECTION_MAP[segment].label.toLowerCase()} visitors arrive from`}
      />

      <div className="mt-2 flex flex-1 flex-col items-center gap-2 sm:flex-row sm:gap-4">
        {/* donut */}
        <div className="relative h-[210px] w-[210px] shrink-0">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                dataKey="value"
                nameKey="label"
                innerRadius="66%"
                outerRadius="88%"
                paddingAngle={3}
                cornerRadius={6}
                stroke={dark ? "#10141C" : "#FFFFFF"}
                strokeWidth={3}
                isAnimationActive
                animationDuration={750}
                animationEasing="ease-out"
                onMouseEnter={(_, i) => setActive(i)}
                onMouseLeave={() => setActive(null)}
              >
                {data.map((s, i) => (
                  <Cell
                    key={s.key}
                    fill={s.color}
                    opacity={active === null || active === i ? 1 : 0.3}
                    style={{ transition: "opacity .25s ease", filter: active === i ? `drop-shadow(0 4px 12px ${s.color}80)` : undefined, cursor: "pointer" }}
                  />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>

          {/* center readout */}
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">
            <span className="tnum font-display text-[26px] leading-none font-bold tracking-tight text-zinc-900 dark:text-white">
              {current ? fmtPct(current.share, 1) : fmtCompact(total)}
            </span>
            <span className="mt-1.5 max-w-[110px] text-[10px] leading-snug font-semibold tracking-[0.14em] text-zinc-400 uppercase dark:text-zinc-500">
              {current ? current.label : "Visitors"}
            </span>
          </div>
        </div>

        {/* legend */}
        <ul className="w-full min-w-0 flex-1 space-y-1">
          {data.map((s, i) => (
            <li key={s.key}>
              <button
                onMouseEnter={() => setActive(i)}
                onMouseLeave={() => setActive(null)}
                onFocus={() => setActive(i)}
                onBlur={() => setActive(null)}
                className={cn(
                  "focusable flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left transition-colors",
                  active === i ? "bg-zinc-900/[0.045] dark:bg-white/[0.06]" : "hover:bg-zinc-900/[0.03] dark:hover:bg-white/[0.04]",
                )}
              >
                <span className="h-2.5 w-2.5 shrink-0 rounded-[4px]" style={{ background: s.color }} />
                <span className="truncate text-[13px] font-medium text-zinc-600 dark:text-zinc-300">{s.label}</span>
                <span className="ml-auto text-right">
                  <span className="tnum block font-mono text-[13px] font-semibold text-zinc-900 dark:text-zinc-100">
                    {fmtFull(s.value)}
                  </span>
                  <span className="tnum block text-[11px] text-zinc-400 dark:text-zinc-500">{fmtPct(s.share, 1)}</span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      </div>
    </Card>
  );
}
