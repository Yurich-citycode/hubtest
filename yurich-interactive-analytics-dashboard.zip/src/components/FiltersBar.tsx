import { useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CalendarDays, Check, ChevronDown, RotateCcw } from "lucide-react";
import { cn } from "../utils/cn";
import { useDismiss } from "../lib/hooks";
import { RANGES, SEGMENTS, type RangeKey, type SegmentKey } from "../lib/data";

/* --------------------------- range segmented ---------------------------- */

function RangeControl({ value, onChange }: { value: RangeKey; onChange: (r: RangeKey) => void }) {
  return (
    <div className="flex items-center rounded-xl border border-zinc-200 bg-white p-1 dark:border-white/10 dark:bg-white/[0.04]">
      {RANGES.map((r) => {
        const active = r.key === value;
        return (
          <button
            key={r.key}
            onClick={() => onChange(r.key)}
            className={cn(
              "focusable relative rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors sm:px-3.5",
              active ? "text-white" : "text-zinc-500 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-white",
            )}
          >
            {active && (
              <motion.span
                layoutId="range-pill"
                transition={{ type: "spring", damping: 30, stiffness: 400 }}
                className="absolute inset-0 rounded-lg bg-gradient-to-br from-indigo-500 to-indigo-600 shadow-[0_4px_12px_-4px_rgba(99,102,241,0.7)]"
              />
            )}
            <span className="relative z-10">{r.label}</span>
          </button>
        );
      })}
    </div>
  );
}

/* --------------------------- segment dropdown ---------------------------- */

function SegmentSelect({ value, onChange }: { value: SegmentKey; onChange: (s: SegmentKey) => void }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useDismiss(ref, () => setOpen(false), open);
  const current = SEGMENTS.find((s) => s.key === value)!;

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className={cn(
          "focusable flex items-center gap-2.5 rounded-xl border py-2 pr-2.5 pl-3.5 text-xs font-semibold transition-colors",
          value === "all"
            ? "border-zinc-200 bg-white text-zinc-700 hover:border-zinc-300 dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-200"
            : "border-indigo-300/70 bg-indigo-500/[0.06] text-indigo-700 dark:border-indigo-400/30 dark:bg-indigo-400/[0.08] dark:text-indigo-300",
        )}
      >
        <span className="h-2 w-2 rounded-full" style={{ background: current.color }} />
        <span className="max-w-[132px] truncate">{current.label}</span>
        <motion.span animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown className="h-3.5 w-3.5 opacity-60" />
        </motion.span>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -6, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.97 }}
            transition={{ duration: 0.16, ease: "easeOut" }}
            className="absolute right-0 z-50 mt-2 w-[248px] origin-top-right rounded-2xl border border-zinc-200/90 bg-white p-1.5 shadow-2xl shadow-zinc-900/10 dark:border-white/10 dark:bg-panel-2 dark:shadow-black/50"
          >
            <p className="px-2.5 pt-1.5 pb-1 text-[10px] font-bold tracking-[0.16em] text-zinc-400 uppercase dark:text-zinc-500">
              Segment traffic by
            </p>
            {SEGMENTS.map((s) => {
              const active = s.key === value;
              return (
                <button
                  key={s.key}
                  onClick={() => {
                    onChange(s.key);
                    setOpen(false);
                  }}
                  className={cn(
                    "flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-left transition-colors",
                    active ? "bg-indigo-500/[0.08] dark:bg-indigo-400/[0.1]" : "hover:bg-zinc-900/[0.04] dark:hover:bg-white/[0.05]",
                  )}
                >
                  <span className="mt-0.5 h-2 w-2 shrink-0 self-start rounded-full" style={{ background: s.color }} />
                  <span className="min-w-0">
                    <span className={cn("block truncate text-[13px] font-semibold", active ? "text-indigo-700 dark:text-indigo-300" : "text-zinc-800 dark:text-zinc-100")}>
                      {s.label}
                    </span>
                    <span className="block truncate text-[11px] text-zinc-400 dark:text-zinc-500">{s.desc}</span>
                  </span>
                  {active && <Check className="ml-auto h-4 w-4 shrink-0 text-indigo-500 dark:text-indigo-400" strokeWidth={2.5} />}
                </button>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* --------------------------------- bar ---------------------------------- */

export default function FiltersBar({
  range,
  onRange,
  segment,
  onSegment,
  rangeLabel,
}: {
  range: RangeKey;
  onRange: (r: RangeKey) => void;
  segment: SegmentKey;
  onSegment: (s: SegmentKey) => void;
  rangeLabel: string;
}) {
  const dirty = range !== "30d" || segment !== "all";
  return (
    <div className="flex flex-wrap items-center gap-2.5">
      <div className="tnum hidden items-center gap-2 rounded-xl border border-zinc-200/80 bg-white/60 px-3 py-2 text-xs font-medium text-zinc-500 xl:flex dark:border-white/[0.07] dark:bg-white/[0.03] dark:text-zinc-400">
        <CalendarDays className="h-3.5 w-3.5" />
        {rangeLabel}
      </div>
      <RangeControl value={range} onChange={onRange} />
      <SegmentSelect value={segment} onChange={onSegment} />
      <AnimatePresence>
        {dirty && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8, x: -4 }}
            animate={{ opacity: 1, scale: 1, x: 0 }}
            exit={{ opacity: 0, scale: 0.8, x: -4 }}
            onClick={() => {
              onRange("30d");
              onSegment("all");
            }}
            className="focusable flex items-center gap-1.5 rounded-xl border border-transparent px-2.5 py-2 text-xs font-semibold text-zinc-400 transition-colors hover:border-zinc-200 hover:bg-white hover:text-zinc-700 dark:hover:border-white/10 dark:hover:bg-white/[0.05] dark:hover:text-zinc-200"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            Reset
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}
