import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Activity,
  BarChart3,
  Database,
  FileText,
  LayoutDashboard,
  LifeBuoy,
  Settings2,
  Share2,
  X,
} from "lucide-react";
import { cn } from "../utils/cn";
import { SEGMENTS, type SegmentKey } from "../lib/data";

const NAV = [
  { id: "kpis", label: "Overview", icon: LayoutDashboard },
  { id: "traffic", label: "Traffic", icon: Activity },
  { id: "sources", label: "Sources", icon: Share2 },
  { id: "content", label: "Top content", icon: BarChart3 },
  { id: "pages", label: "Pages table", icon: FileText },
];

function SidebarBody({
  active,
  onNav,
  segment,
  onSegment,
}: {
  active: string;
  onNav: (id: string) => void;
  segment: SegmentKey;
  onSegment: (s: SegmentKey) => void;
}) {
  return (
    <div className="flex h-full flex-col">
      <nav className="flex-1 space-y-6 overflow-y-auto px-1 py-5">
        <div>
          <p className="px-3 pb-2 text-[10px] font-bold tracking-[0.18em] text-zinc-400 uppercase dark:text-zinc-500">
            Analytics
          </p>
          <ul className="space-y-0.5">
            {NAV.map((item) => {
              const Icon = item.icon;
              const isActive = active === item.id;
              return (
                <li key={item.id}>
                  <button
                    onClick={() => onNav(item.id)}
                    className={cn(
                      "focusable group relative flex w-full items-center gap-3 rounded-xl px-3 py-2 text-[13px] font-medium transition-colors",
                      isActive
                        ? "bg-indigo-500/[0.09] text-indigo-700 dark:bg-indigo-400/[0.12] dark:text-indigo-300"
                        : "text-zinc-500 hover:bg-zinc-900/[0.04] hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-white/[0.05] dark:hover:text-white",
                    )}
                  >
                    {isActive && (
                      <motion.span
                        layoutId="nav-indicator"
                        className="absolute top-1/2 left-0 h-5 w-[3px] -translate-y-1/2 rounded-r-full bg-indigo-500 dark:bg-indigo-400"
                      />
                    )}
                    <Icon className="h-4 w-4 shrink-0" strokeWidth={isActive ? 2.4 : 2} />
                    {item.label}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>

        <div>
          <p className="px-3 pb-2 text-[10px] font-bold tracking-[0.18em] text-zinc-400 uppercase dark:text-zinc-500">
            Hub sections
          </p>
          <ul className="space-y-0.5">
            {SEGMENTS.filter((s) => s.key !== "all").map((s) => {
              const isActive = segment === s.key;
              return (
                <li key={s.key}>
                  <button
                    onClick={() => onSegment(isActive ? "all" : s.key)}
                    className={cn(
                      "focusable flex w-full items-center gap-3 rounded-xl px-3 py-2 text-[13px] font-medium transition-colors",
                      isActive
                        ? "bg-zinc-900/[0.05] text-zinc-900 dark:bg-white/[0.07] dark:text-white"
                        : "text-zinc-500 hover:bg-zinc-900/[0.04] hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-white/[0.05] dark:hover:text-white",
                    )}
                  >
                    <span
                      className="h-2 w-2 shrink-0 rounded-full ring-2 transition-shadow"
                      style={{ background: s.color, boxShadow: isActive ? `0 0 0 2px ${s.color}33` : undefined }}
                    />
                    {s.label}
                    {isActive && <span className="ml-auto text-[10px] font-bold tracking-wider text-zinc-400 uppercase">On</span>}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </nav>

      <div className="space-y-3 border-t border-zinc-200/70 px-1 pt-4 pb-2 dark:border-white/[0.06]">
        <div className="rounded-xl border border-zinc-200/80 bg-zinc-50/80 p-3 dark:border-white/[0.06] dark:bg-white/[0.03]">
          <div className="flex items-center gap-2 text-xs font-semibold text-zinc-700 dark:text-zinc-200">
            <Database className="h-3.5 w-3.5 text-indigo-500 dark:text-indigo-400" />
            Sample dataset
          </div>
          <p className="mt-1 text-[11px] leading-relaxed text-zinc-400 dark:text-zinc-500">
            210 days · deterministic seed · updates live with filters
          </p>
        </div>
        <div className="flex items-center gap-1 px-1 text-zinc-400 dark:text-zinc-500">
          <button className="focusable flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-medium transition-colors hover:text-zinc-700 dark:hover:text-zinc-200">
            <Settings2 className="h-3.5 w-3.5" /> Settings
          </button>
          <button className="focusable flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-medium transition-colors hover:text-zinc-700 dark:hover:text-zinc-200">
            <LifeBuoy className="h-3.5 w-3.5" /> Support
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Sidebar({
  segment,
  onSegment,
  mobileOpen,
  onCloseMobile,
}: {
  segment: SegmentKey;
  onSegment: (s: SegmentKey) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}) {
  const [active, setActive] = useState("kpis");

  const onNav = (id: string) => {
    setActive(id);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
    onCloseMobile();
  };

  // keep nav highlight in sync while scrolling
  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => {
        for (const e of entries) if (e.isIntersecting) setActive(e.target.id);
      },
      { rootMargin: "-30% 0px -60% 0px" },
    );
    NAV.forEach((n) => {
      const el = document.getElementById(n.id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, []);

  return (
    <>
      {/* desktop */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-[248px] border-r border-zinc-200/70 bg-white/60 px-3 backdrop-blur-xl lg:block dark:border-white/[0.06] dark:bg-[#0b0e14]/80">
        <SidebarBody active={active} onNav={onNav} segment={segment} onSegment={onSegment} />
      </aside>

      {/* mobile drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onCloseMobile}
              className="fixed inset-0 z-40 bg-zinc-950/40 backdrop-blur-sm lg:hidden"
            />
            <motion.aside
              initial={{ x: -300 }}
              animate={{ x: 0 }}
              exit={{ x: -300 }}
              transition={{ type: "spring", damping: 30, stiffness: 320 }}
              className="fixed inset-y-0 left-0 z-50 w-[272px] border-r border-zinc-200 bg-white px-3 lg:hidden dark:border-white/[0.08] dark:bg-[#0b0e14]"
            >
              <button
                onClick={onCloseMobile}
                aria-label="Close navigation"
                className="focusable absolute top-4 right-3 grid h-8 w-8 place-items-center rounded-lg text-zinc-400 transition-colors hover:bg-zinc-900/5 hover:text-zinc-900 dark:hover:bg-white/[0.06] dark:hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
              <SidebarBody
                active={active}
                onNav={onNav}
                segment={segment}
                onSegment={(s) => {
                  onSegment(s);
                  onCloseMobile();
                }}
              />
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
