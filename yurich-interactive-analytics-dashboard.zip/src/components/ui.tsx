import { useId, type ReactNode } from "react";
import { motion } from "framer-motion";
import { ArrowDownRight, ArrowUpRight, Minus } from "lucide-react";
import { Area, AreaChart, ResponsiveContainer } from "recharts";
import { cn } from "../utils/cn";
import { fmtDelta } from "../lib/data";

/* ---------------------------------- card ---------------------------------- */

export function Card({
  id,
  className,
  children,
}: {
  id?: string;
  className?: string;
  children: ReactNode;
}) {
  return (
    <section id={id} className={cn("card scroll-mt-24", className)}>
      {children}
    </section>
  );
}

export function CardHeader({
  title,
  sub,
  right,
  className,
}: {
  title: string;
  sub?: string;
  right?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-wrap items-start justify-between gap-3", className)}>
      <div>
        <h3 className="font-display text-[15px] font-semibold tracking-tight text-zinc-900 dark:text-white">
          {title}
        </h3>
        {sub && <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">{sub}</p>}
      </div>
      {right}
    </div>
  );
}

/* ------------------------------ delta badge ------------------------------- */

export function DeltaBadge({ delta, className }: { delta: number; className?: string }) {
  const up = delta > 0.0005;
  const flat = Math.abs(delta) <= 0.0005;
  const Icon = flat ? Minus : up ? ArrowUpRight : ArrowDownRight;
  return (
    <span
      className={cn(
        "tnum inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold ring-1",
        flat
          ? "bg-zinc-500/10 text-zinc-500 ring-zinc-500/20 dark:text-zinc-400"
          : up
            ? "bg-emerald-500/10 text-emerald-600 ring-emerald-500/20 dark:text-emerald-400"
            : "bg-rose-500/10 text-rose-600 ring-rose-500/20 dark:text-rose-400",
        className,
      )}
    >
      <Icon className="h-3 w-3" strokeWidth={2.5} />
      {fmtDelta(delta)}
    </span>
  );
}

/* -------------------------------- sparkline ------------------------------- */

export function Spark({
  data,
  color,
  height = 40,
  strokeWidth = 2,
  className,
}: {
  data: number[];
  color: string;
  height?: number;
  strokeWidth?: number;
  className?: string;
}) {
  const gid = useId().replace(/[^a-zA-Z0-9]/g, "");
  const points = data.map((v, i) => ({ i, v }));
  return (
    <div className={cn("w-full", className)} style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={points} margin={{ top: 2, right: 0, bottom: 0, left: 0 }}>
          <defs>
            <linearGradient id={`sp-${gid}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.28} />
              <stop offset="100%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <Area
            type="monotone"
            dataKey="v"
            stroke={color}
            strokeWidth={strokeWidth}
            fill={`url(#sp-${gid})`}
            isAnimationActive
            animationDuration={650}
            dot={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

/* ----------------------------- chart tooltip ------------------------------ */

export interface TipRow {
  dot: string;
  label: string;
  value: string;
}

export function TooltipShell({ title, rows }: { title: string; rows: TipRow[] }) {
  return (
    <div className="min-w-[190px] rounded-xl border border-zinc-200/80 bg-white/95 px-3.5 py-3 shadow-xl shadow-zinc-900/10 backdrop-blur-md dark:border-white/10 dark:bg-panel-2/95 dark:shadow-black/40">
      <p className="mb-2 text-[11px] font-semibold tracking-wide text-zinc-500 uppercase dark:text-zinc-400">
        {title}
      </p>
      <div className="space-y-1.5">
        {rows.map((r) => (
          <div key={r.label} className="flex items-center gap-2.5">
            <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: r.dot }} />
            <span className="text-xs text-zinc-500 dark:text-zinc-400">{r.label}</span>
            <span className="tnum ml-auto font-mono text-xs font-semibold text-zinc-900 dark:text-zinc-100">
              {r.value}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------ reveal anim ------------------------------- */

export function Reveal({
  children,
  delay = 0,
  className,
  id,
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  id?: string;
}) {
  return (
    <motion.div
      id={id}
      className={className}
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-32px" }}
      transition={{ duration: 0.55, delay, ease: [0.21, 0.65, 0.35, 1] }}
    >
      {children}
    </motion.div>
  );
}
