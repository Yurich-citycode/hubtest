import { useState } from "react";
import {
  Area,
  CartesianGrid,
  ComposedChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { cn } from "../utils/cn";
import { Card, CardHeader, TooltipShell } from "./ui";
import { fmtCompact, fmtFull, fmtPct, fmtTick, fmtTooltipDate, type RangeKey, type SeriesPoint } from "../lib/data";

function Tip({ active, payload, showSessions }: any) {
  if (!active || !payload?.length) return null;
  const d = payload[0].payload as SeriesPoint;
  return (
    <TooltipShell
      title={fmtTooltipDate(d.date)}
      rows={[
        { dot: "#6366F1", label: "Visitors", value: fmtFull(d.visitors) },
        ...(showSessions ? [{ dot: "#22D3EE", label: "Sessions", value: fmtFull(d.sessions) }] : []),
        { dot: "#FBBF24", label: "Keys issued", value: fmtFull(d.keys) },
        { dot: "#94A3B8", label: "Conv. rate", value: fmtPct(d.conversion) },
      ]}
    />
  );
}

export default function TrafficChart({
  data,
  dark,
  range,
  rangeLabel,
}: {
  data: SeriesPoint[];
  dark: boolean;
  range: RangeKey;
  rangeLabel: string;
}) {
  const [showVisitors, setShowVisitors] = useState(true);
  const [showSessions, setShowSessions] = useState(true);

  // never leave the chart completely empty
  const toggleVisitors = () => {
    if (!showVisitors) setShowVisitors(true);
    else if (showSessions) setShowVisitors(false);
    else setShowSessions(true);
  };
  const toggleSessions = () => {
    if (!showSessions) setShowSessions(true);
    else if (showVisitors) setShowSessions(false);
    else setShowVisitors(true);
  };

  const cVisitors = dark ? "#818CF8" : "#6366F1";
  const cSessions = dark ? "#22D3EE" : "#06B6D4";
  const grid = dark ? "rgba(148,163,184,0.09)" : "#E7EAF1";
  const tick = dark ? "#5B6472" : "#98A2B3";
  const total = data.reduce((a, d) => a + d.visitors, 0);

  const LegendChip = ({
    on,
    onClick,
    color,
    label,
  }: {
    on: boolean;
    onClick: () => void;
    color: string;
    label: string;
  }) => (
    <button
      onClick={onClick}
      className={cn(
        "focusable flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-[11px] font-semibold transition-all",
        on
          ? "border-zinc-200 bg-white text-zinc-700 dark:border-white/10 dark:bg-white/[0.05] dark:text-zinc-200"
          : "border-transparent text-zinc-400 line-through opacity-60 hover:opacity-100 dark:text-zinc-500",
      )}
    >
      <span className="h-2 w-2 rounded-full" style={{ background: color }} />
      {label}
    </button>
  );

  return (
    <Card id="traffic" className="p-5 sm:p-6">
      <CardHeader
        title="Traffic over time"
        sub={`${rangeLabel} · ${fmtCompact(total)} visitors total`}
        right={
          <div className="flex items-center gap-1.5">
            <LegendChip on={showVisitors} onClick={toggleVisitors} color={cVisitors} label="Visitors" />
            <LegendChip on={showSessions} onClick={toggleSessions} color={cSessions} label="Sessions" />
          </div>
        }
      />

      <div className="mt-5 h-[300px] w-full sm:h-[320px]">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 6, right: 4, bottom: 0, left: -8 }}>
            <defs>
              <linearGradient id="tg-visitors" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={cVisitors} stopOpacity={dark ? 0.32 : 0.22} />
                <stop offset="100%" stopColor={cVisitors} stopOpacity={0} />
              </linearGradient>
              <linearGradient id="tg-sessions" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={cSessions} stopOpacity={dark ? 0.2 : 0.12} />
                <stop offset="100%" stopColor={cSessions} stopOpacity={0} />
              </linearGradient>
            </defs>

            <CartesianGrid vertical={false} stroke={grid} strokeDasharray="3 6" />
            <XAxis
              dataKey="date"
              tickFormatter={(d: Date) => fmtTick(d, range)}
              tickLine={false}
              axisLine={false}
              tick={{ fill: tick }}
              dy={8}
              minTickGap={28}
            />
            <YAxis
              tickFormatter={(v: number) => fmtCompact(v)}
              tickLine={false}
              axisLine={false}
              tick={{ fill: tick }}
              width={48}
              domain={[0, "auto"]}
            />
            <Tooltip
              content={<Tip showSessions={showSessions} />}
              cursor={{ stroke: dark ? "rgba(148,163,184,0.25)" : "#C7CDDA", strokeWidth: 1, strokeDasharray: "4 4" }}
            />

            {showSessions && (
              <Area
                type="monotone"
                dataKey="sessions"
                stroke={cSessions}
                strokeWidth={2}
                fill="url(#tg-sessions)"
                dot={false}
                activeDot={{ r: 4, strokeWidth: 2, stroke: dark ? "#10141C" : "#fff" }}
                isAnimationActive
                animationDuration={700}
                animationEasing="ease-out"
              />
            )}
            {showVisitors && (
              <Area
                type="monotone"
                dataKey="visitors"
                stroke={cVisitors}
                strokeWidth={2.5}
                fill="url(#tg-visitors)"
                dot={false}
                activeDot={{ r: 4.5, strokeWidth: 2, stroke: dark ? "#10141C" : "#fff" }}
                isAnimationActive
                animationDuration={700}
                animationEasing="ease-out"
              />
            )}
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}
