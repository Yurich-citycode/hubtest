import { useEffect, useRef } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, Bell, Menu, Moon, Radar, Search, Sun } from "lucide-react";
import { cn } from "../utils/cn";
import { useLiveCount } from "../lib/hooks";
import type { SegmentKey } from "../lib/data";

function ThemeToggle({ dark, onToggle }: { dark: boolean; onToggle: () => void }) {
  return (
    <button
      onClick={onToggle}
      aria-label="Toggle dark mode"
      className={cn(
        "focusable relative grid h-9 w-9 place-items-center overflow-hidden rounded-xl border transition-colors",
        "border-zinc-200 bg-white text-zinc-600 hover:bg-zinc-50 hover:text-zinc-900",
        "dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-300 dark:hover:bg-white/[0.08] dark:hover:text-white",
      )}
    >
      <AnimatePresence mode="wait" initial={false}>
        <motion.span
          key={dark ? "moon" : "sun"}
          initial={{ y: 12, opacity: 0, rotate: -50 }}
          animate={{ y: 0, opacity: 1, rotate: 0 }}
          exit={{ y: -12, opacity: 0, rotate: 50 }}
          transition={{ duration: 0.22, ease: "easeOut" }}
          className="grid place-items-center"
        >
          {dark ? <Moon className="h-[17px] w-[17px]" /> : <Sun className="h-[17px] w-[17px]" />}
        </motion.span>
      </AnimatePresence>
    </button>
  );
}

export default function Topbar({
  dark,
  onToggleDark,
  onOpenNav,
  segment,
  onResetFilters,
}: {
  dark: boolean;
  onToggleDark: () => void;
  onOpenNav: () => void;
  segment: SegmentKey;
  onResetFilters: () => void;
}) {
  const live = useLiveCount(segment);
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        searchRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <header className="sticky top-0 z-40 border-b border-zinc-200/70 bg-[#f3f5f9]/80 backdrop-blur-xl transition-colors dark:border-white/[0.06] dark:bg-ink/75">
      <div className="mx-auto flex h-16 max-w-[1480px] items-center gap-3 px-4 sm:px-6">
        <button
          onClick={onOpenNav}
          aria-label="Open navigation"
          className="focusable -ml-1 grid h-9 w-9 place-items-center rounded-xl text-zinc-500 transition-colors hover:bg-zinc-900/5 hover:text-zinc-900 lg:hidden dark:text-zinc-400 dark:hover:bg-white/[0.06] dark:hover:text-white"
        >
          <Menu className="h-5 w-5" />
        </button>

        {/* brand */}
        <a href="#top" className="flex items-center gap-2.5" onClick={onResetFilters}>
          <span className="grid h-8 w-8 place-items-center rounded-[10px] bg-gradient-to-br from-indigo-500 via-indigo-600 to-cyan-500 shadow-[0_4px_14px_-4px_rgba(99,102,241,0.6)]">
            <Radar className="h-[18px] w-[18px] text-white" strokeWidth={2.2} />
          </span>
          <span className="leading-none">
            <span className="block font-display text-[15px] font-bold tracking-tight text-zinc-900 dark:text-white">
              YurichHub
            </span>
            <span className="mt-0.5 block text-[10px] font-semibold tracking-[0.18em] text-zinc-400 uppercase dark:text-zinc-500">
              Analytics
            </span>
          </span>
        </a>

        {/* search */}
        <div className="mx-auto hidden w-full max-w-sm items-center md:flex">
          <div className="group flex w-full items-center gap-2.5 rounded-xl border border-zinc-200/90 bg-white/80 px-3.5 py-2 text-zinc-400 transition-all focus-within:border-indigo-400 focus-within:ring-4 focus-within:ring-indigo-500/10 dark:border-white/[0.08] dark:bg-white/[0.04] dark:focus-within:border-indigo-400/60">
            <Search className="h-4 w-4 shrink-0" />
            <input
              ref={searchRef}
              placeholder="Search pages, sources, sections…"
              className="w-full bg-transparent text-[13px] text-zinc-700 outline-none placeholder:text-zinc-400 dark:text-zinc-200 dark:placeholder:text-zinc-500"
            />
            <kbd className="kbd shrink-0">⌘K</kbd>
          </div>
        </div>

        <div className="ml-auto flex items-center gap-2 md:gap-2.5">
          {/* live */}
          <div
            className="tnum hidden items-center gap-2 rounded-full border border-emerald-500/25 bg-emerald-500/[0.08] py-1.5 pr-3 pl-2.5 text-xs font-semibold text-emerald-700 sm:flex dark:text-emerald-300"
            title="Visitors currently on the hub (simulated)"
          >
            <span className="relative flex h-2 w-2">
              <span className="live-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
            </span>
            {live} on hub now
          </div>

          <a
            href="https://yurich-citycode.github.io/hubtest/index.html"
            target="_blank"
            rel="noreferrer"
            className="focusable hidden items-center gap-1.5 rounded-xl border border-zinc-200 bg-white px-3 py-2 text-xs font-semibold text-zinc-600 transition-colors hover:border-indigo-300 hover:text-indigo-600 md:flex dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-300 dark:hover:border-indigo-400/40 dark:hover:text-indigo-300"
          >
            Live hub
            <ArrowUpRight className="h-3.5 w-3.5" />
          </a>

          <ThemeToggle dark={dark} onToggle={onToggleDark} />

          <button
            aria-label="Notifications"
            className="focusable relative hidden h-9 w-9 place-items-center rounded-xl border border-zinc-200 bg-white text-zinc-500 transition-colors hover:text-zinc-900 sm:grid dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-400 dark:hover:text-white"
          >
            <Bell className="h-[17px] w-[17px]" />
            <span className="absolute top-2 right-2 h-1.5 w-1.5 rounded-full bg-rose-500 ring-2 ring-white dark:ring-panel" />
          </button>

          <div className="flex items-center gap-2.5 rounded-xl border border-transparent py-0.5 pr-1 pl-0.5 sm:border-zinc-200 sm:bg-white sm:pr-3 sm:pl-1 dark:sm:border-white/10 dark:sm:bg-white/[0.04]">
            <span className="grid h-8 w-8 place-items-center rounded-[10px] bg-gradient-to-br from-indigo-500 to-cyan-400 font-display text-sm font-bold text-white">
              Y
            </span>
            <span className="hidden leading-tight sm:block">
              <span className="block text-[13px] font-semibold text-zinc-900 dark:text-white">YuRich</span>
              <span className="block text-[11px] text-zinc-400 dark:text-zinc-500">Owner</span>
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}
