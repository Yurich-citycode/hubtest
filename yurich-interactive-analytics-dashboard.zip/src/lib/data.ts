/* ------------------------------------------------------------------ */
/*  YurichHub Analytics — deterministic sample data engine             */
/*  All views derive from one 210-day generated history, so every      */
/*  filter (range / segment) recomputes consistently across views.     */
/* ------------------------------------------------------------------ */

export type RangeKey = "7d" | "14d" | "30d" | "90d";
export type SegmentKey = "all" | "sevai" | "citycode" | "rwa" | "course" | "biz";
export type SourceKey = "organic" | "direct" | "social" | "referral" | "email";

export const RANGES: { key: RangeKey; label: string; days: number }[] = [
  { key: "7d", label: "7D", days: 7 },
  { key: "14d", label: "14D", days: 14 },
  { key: "30d", label: "30D", days: 30 },
  { key: "90d", label: "90D", days: 90 },
];

export const SEGMENTS: { key: SegmentKey; label: string; desc: string; color: string }[] = [
  { key: "all", label: "All sections", desc: "Entire YurichHub traffic", color: "#6366F1" },
  { key: "sevai", label: "Sevastopol AI", desc: "Living voice of the city", color: "#22D3EE" },
  { key: "citycode", label: "City Code", desc: "Keys & member system", color: "#A78BFA" },
  { key: "rwa", label: "Crimea RWA", desc: "Ownership infrastructure", color: "#34D399" },
  { key: "course", label: "RWA Course", desc: "Course, glossary & book", color: "#FBBF24" },
  { key: "biz", label: "For Business", desc: "ЦФА builds & consults", color: "#FB7185" },
];

export const SECTION_MAP = Object.fromEntries(SEGMENTS.map((s) => [s.key, s])) as Record<
  SegmentKey,
  (typeof SEGMENTS)[number]
>;

export const SOURCES: { key: SourceKey; label: string; color: string }[] = [
  { key: "organic", label: "Organic search", color: "#6366F1" },
  { key: "direct", label: "Direct", color: "#22D3EE" },
  { key: "social", label: "Social", color: "#A78BFA" },
  { key: "referral", label: "Referral", color: "#FBBF24" },
  { key: "email", label: "Email", color: "#FB7185" },
];

/* ------------------------------ PRNG ------------------------------ */

function mulberry32(seed: number) {
  return function () {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

/** tiny deterministic hash → 0..1 */
function hash01(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return ((h >>> 0) % 10000) / 10000;
}

/* ---------------------------- generation --------------------------- */

const DAYS = 210; // supports 90-day range + previous-period comparison
const SEED = 20260212;

const SECTION_KEYS = ["sevai", "citycode", "rwa", "course", "biz"] as const;
type SectionKey = (typeof SECTION_KEYS)[number];

const BASE_SHARE: Record<SectionKey, number> = {
  sevai: 0.34,
  citycode: 0.26,
  rwa: 0.15,
  course: 0.15,
  biz: 0.1,
};
const SHARE_PHASE: Record<SectionKey, number> = { sevai: 0.4, citycode: 2.1, rwa: 3.6, course: 5.0, biz: 1.1 };
const SHARE_PERIOD: Record<SectionKey, number> = { sevai: 97, citycode: 71, rwa: 121, course: 83, biz: 63 };

const BASE_MIX: Record<SectionKey, Record<SourceKey, number>> = {
  sevai: { organic: 0.22, direct: 0.15, social: 0.39, referral: 0.14, email: 0.1 },
  citycode: { organic: 0.24, direct: 0.3, social: 0.18, referral: 0.16, email: 0.12 },
  rwa: { organic: 0.34, direct: 0.12, social: 0.1, referral: 0.2, email: 0.24 },
  course: { organic: 0.4, direct: 0.1, social: 0.22, referral: 0.12, email: 0.16 },
  biz: { organic: 0.22, direct: 0.34, social: 0.06, referral: 0.26, email: 0.12 },
};

interface PageDef {
  id: string;
  title: string;
  path: string;
  section: SectionKey;
  weight: number;
  convRate: number; // base conv rate for this page
}

const PAGES: PageDef[] = [
  { id: "p01", title: "Sevastopol AI — City Guide", path: "/sevastopol-ai", section: "sevai", weight: 0.34, convRate: 0.021 },
  { id: "p02", title: "Routes & New Paths", path: "/sevastopol-ai/routes", section: "sevai", weight: 0.2, convRate: 0.016 },
  { id: "p03", title: "Sunset & Evening Picks", path: "/sevastopol-ai/evening", section: "sevai", weight: 0.17, convRate: 0.013 },
  { id: "p04", title: "City Code — Overview", path: "/city-code", section: "citycode", weight: 0.26, convRate: 0.055 },
  { id: "p05", title: "The Code — Rules of the System", path: "/city-code/code", section: "citycode", weight: 0.2, convRate: 0.044 },
  { id: "p06", title: "Partners & Privileges", path: "/city-code/partners", section: "citycode", weight: 0.16, convRate: 0.061 },
  { id: "p07", title: "Community & Events", path: "/city-code/events", section: "citycode", weight: 0.12, convRate: 0.03 },
  { id: "p08", title: "Crimea RWA — Overview", path: "/crimea-rwa", section: "rwa", weight: 0.22, convRate: 0.028 },
  { id: "p09", title: "Ownership Infrastructure", path: "/crimea-rwa/infrastructure", section: "rwa", weight: 0.13, convRate: 0.024 },
  { id: "p10", title: "RWA Course — Landing", path: "/course", section: "course", weight: 0.19, convRate: 0.052 },
  { id: "p11", title: "Glossary — Subscriber Access", path: "/glossary", section: "course", weight: 0.11, convRate: 0.047 },
  { id: "p12", title: "Book «RWA / ЦФА. Tokenization»", path: "/book", section: "course", weight: 0.09, convRate: 0.039 },
  { id: "p13", title: "For Business — ЦФА Assembly", path: "/for-business", section: "biz", weight: 0.1, convRate: 0.078 },
  { id: "p14", title: "Consultation — 80 000 ₽", path: "/for-business/consult", section: "biz", weight: 0.05, convRate: 0.114 },
];

interface DayRow {
  date: Date;
  visitors: number;
  sessions: number;
  pageviews: number;
  keys: number;
  bounce: number;
  avgSession: number; // seconds
  shares: Record<SectionKey, number>;
  mix: Record<SectionKey, Record<SourceKey, number>>;
  pageViews: Record<string, number>;
}

interface Store {
  days: DayRow[];
  liveBase: Record<SegmentKey, number>;
}

function build(): Store {
  const rand = mulberry32(SEED);
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const campaigns = [
    { at: DAYS - 33, amp: 0.5, w: 2.6 }, // City Code push
    { at: DAYS - 59, amp: 0.9, w: 2.1 }, // course launch spike
    { at: DAYS - 78, amp: 0.42, w: 3.2 },
    { at: DAYS - 11, amp: 0.34, w: 2.2 }, // recent promo
  ];

  const days: DayRow[] = [];

  for (let i = 0; i < DAYS; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() - (DAYS - 1 - i));
    const dw = date.getDay();

    const growth = Math.pow(1.0035, i);
    const weekend = dw === 0 || dw === 6 ? 1.16 : 0.98;
    let campaign = 1;
    for (const c of campaigns) campaign += c.amp * Math.exp(-((i - c.at) ** 2) / (2 * c.w * c.w));

    const visitors = Math.round(1720 * growth * weekend * campaign * (0.9 + 0.2 * rand()));
    const convRate = 0.052 * (0.9 + 0.2 * rand()) * (1 + 0.07 * Math.sin(i / 23));
    const keys = Math.round(visitors * convRate);
    const sessions = Math.round(visitors * (1.38 + 0.12 * rand()));
    const pageviews = Math.round(sessions * (2.5 + 0.6 * rand()));
    const bounce = clamp(0.44 - 0.00045 * i + 0.06 * (rand() - 0.5), 0.27, 0.52);
    const avgSession = Math.round(218 + 0.42 * i + 34 * (rand() - 0.5));

    // segment shares (slow-drifting, normalized)
    const raw = {} as Record<SectionKey, number>;
    let rSum = 0;
    for (const s of SECTION_KEYS) {
      raw[s] =
        BASE_SHARE[s] *
        (1 + 0.16 * Math.sin(i / SHARE_PERIOD[s] + SHARE_PHASE[s])) *
        (0.92 + 0.16 * rand());
      rSum += raw[s];
    }
    const shares = {} as Record<SectionKey, number>;
    for (const s of SECTION_KEYS) shares[s] = raw[s] / rSum;

    // traffic-source mix per section
    const mix = {} as Record<SectionKey, Record<SourceKey, number>>;
    for (const s of SECTION_KEYS) {
      const m = {} as Record<SourceKey, number>;
      let mSum = 0;
      (Object.keys(BASE_MIX[s]) as SourceKey[]).forEach((k) => {
        m[k] = BASE_MIX[s][k] * (0.88 + 0.24 * rand());
        mSum += m[k];
      });
      (Object.keys(m) as SourceKey[]).forEach((k) => (m[k] /= mSum));
      mix[s] = m;
    }

    // per-page views
    const pageViews: Record<string, number> = {};
    for (const s of SECTION_KEYS) {
      const sPages = PAGES.filter((p) => p.section === s);
      const wSum = sPages.reduce((a, p) => a + p.weight, 0);
      const sViews = pageviews * shares[s];
      for (const p of sPages) {
        pageViews[p.id] = Math.round(sViews * (p.weight / wSum) * (0.85 + 0.3 * rand()));
      }
    }

    days.push({ date, visitors, sessions, pageviews, keys, bounce, avgSession, shares, mix, pageViews });
  }

  // live "currently on hub" baseline per segment (~per-minute visitors × 4)
  const last = days[DAYS - 1];
  const liveBase = { all: Math.max(28, Math.round(last.visitors / 240)) } as Record<SegmentKey, number>;
  for (const s of SECTION_KEYS) liveBase[s] = Math.max(4, Math.round(liveBase.all * last.shares[s]));

  return { days, liveBase };
}

const STORE = build();

/* ----------------------------- selectors --------------------------- */

const rangeDays = (r: RangeKey) => RANGES.find((x) => x.key === r)!.days;

/** [start, endExclusive] indices for current + previous windows */
function windows(range: RangeKey): { cur: [number, number]; prev: [number, number] } {
  const n = rangeDays(range);
  const end = DAYS;
  return { cur: [end - n, end], prev: [end - 2 * n, end - n] };
}

const segFactor = (d: DayRow, seg: SegmentKey) => (seg === "all" ? 1 : d.shares[seg as SectionKey]);

/** different parts of the hub convert at very different rates */
const SEG_CONV: Record<SectionKey, number> = { sevai: 0.42, citycode: 1.5, rwa: 0.72, course: 1.22, biz: 1.74 };
const segConvMult = (seg: SegmentKey) =>
  seg === "all" ? weightedConvMult() : SEG_CONV[seg as SectionKey];
let _wcm: number | null = null;
function weightedConvMult(): number {
  if (_wcm === null)
    _wcm = SECTION_KEYS.reduce((a, s) => a + BASE_SHARE[s] * SEG_CONV[s], 0);
  return _wcm;
}

export interface SeriesPoint {
  date: Date;
  visitors: number;
  sessions: number;
  keys: number;
  conversion: number; // 0..1
}

export function getSeries(range: RangeKey, segment: SegmentKey): SeriesPoint[] {
  const { cur } = windows(range);
  const cm = segConvMult(segment);
  return STORE.days.slice(cur[0], cur[1]).map((d) => {
    const f = segFactor(d, segment);
    const visitors = Math.round(d.visitors * f);
    const keys = Math.round(d.keys * f * cm);
    return {
      date: d.date,
      visitors,
      sessions: Math.round(d.sessions * f),
      keys,
      conversion: visitors > 0 ? keys / visitors : 0,
    };
  });
}

/* KPIs --------------------------------------------------------------- */

export type KpiFormat = "int" | "pct" | "dur" | "num1";

export interface Kpi {
  id: "visitors" | "pageviews" | "conversion" | "avgsession";
  label: string;
  value: number;
  delta: number; // vs previous period
  format: KpiFormat;
  spark: number[];
}

export function getKpis(range: RangeKey, segment: SegmentKey): Kpi[] {
  const { cur, prev } = windows(range);

  const agg = (a: number, b: number) => {
    let v = 0, pv = 0, k = 0, sess = 0, asW = 0;
    for (let i = a; i < b; i++) {
      const d = STORE.days[i];
      const f = segFactor(d, segment);
      v += d.visitors * f;
      pv += d.pageviews * f;
      k += d.keys * f;
      sess += d.sessions * f;
      asW += d.avgSession * d.sessions * f;
    }
    return { v, pv, k, sess, avg: sess ? asW / sess : 0, conv: v ? k / v : 0 };
  };

  const c = agg(cur[0], cur[1]);
  const p = agg(prev[0], prev[1]);
  const delta = (a: number, b: number) => (b === 0 ? 0 : (a - b) / b);
  const cm = segConvMult(segment);

  const daily = (pick: (d: DayRow) => number, scale: boolean) =>
    decimate(STORE.days.slice(cur[0], cur[1]).map((d) => (scale ? pick(d) * segFactor(d, segment) : pick(d))), 36);

  return [
    { id: "visitors", label: "Unique visitors", value: Math.round(c.v), delta: delta(c.v, p.v), format: "int", spark: daily((d) => d.visitors, true) },
    { id: "pageviews", label: "Page views", value: Math.round(c.pv), delta: delta(c.pv, p.pv), format: "int", spark: daily((d) => d.pageviews, true) },
    {
      id: "conversion",
      label: "Conversion rate",
      value: c.conv * cm,
      delta: delta(c.conv * cm, p.conv * cm),
      format: "pct",
      spark: daily((d) => (d.keys / Math.max(1, d.visitors)) * cm, false),
    },
    { id: "avgsession", label: "Avg. session", value: Math.round(c.avg), delta: delta(c.avg, p.avg), format: "dur", spark: daily((d) => d.avgSession, false) },
  ];
}

/* Sources ------------------------------------------------------------ */

export interface SourceDatum {
  key: SourceKey;
  label: string;
  color: string;
  value: number;
  share: number;
}

export function getSources(range: RangeKey, segment: SegmentKey): SourceDatum[] {
  const { cur } = windows(range);
  const totals: Record<SourceKey, number> = { organic: 0, direct: 0, social: 0, referral: 0, email: 0 };

  for (let i = cur[0]; i < cur[1]; i++) {
    const d = STORE.days[i];
    if (segment === "all") {
      for (const s of SECTION_KEYS) {
        const sv = d.visitors * d.shares[s];
        (Object.keys(totals) as SourceKey[]).forEach((k) => (totals[k] += sv * d.mix[s][k]));
      }
    } else {
      const sv = d.visitors * d.shares[segment as SectionKey];
      (Object.keys(totals) as SourceKey[]).forEach((k) => (totals[k] += sv * d.mix[segment as SectionKey][k]));
    }
  }

  const sum = Object.values(totals).reduce((a, b) => a + b, 0) || 1;
  return SOURCES.map((s) => ({
    ...s,
    value: Math.round(totals[s.key]),
    share: totals[s.key] / sum,
  })).sort((a, b) => b.value - a.value);
}

/* Table / top pages --------------------------------------------------- */

export interface TableRow {
  id: string;
  title: string;
  path: string;
  section: SectionKey;
  views: number;
  delta: number;
  uniques: number;
  conv: number;
  convRate: number;
  bounce: number;
  avgTime: number;
  spark: number[];
}

export function getRows(range: RangeKey, segment: SegmentKey): TableRow[] {
  const { cur, prev } = windows(range);
  const n = cur[1] - cur[0];

  return PAGES.filter((p) => segment === "all" || p.section === segment).map((p) => {
    let views = 0, prevViews = 0;
    const spark: number[] = [];
    for (let i = cur[0]; i < cur[1]; i++) {
      views += STORE.days[i].pageViews[p.id];
      spark.push(STORE.days[i].pageViews[p.id]);
    }
    for (let i = prev[0]; i < prev[1]; i++) prevViews += STORE.days[i].pageViews[p.id];

    const h = hash01(p.id);
    const h2 = hash01(p.id + "::2");
    const convMult = 0.85 + 0.3 * h2 + (range === "7d" ? 0.06 * (h - 0.5) : 0);
    const conv = Math.round(views * p.convRate * convMult);
    const uniques = Math.round(views * (0.58 + 0.12 * h));

    // reconstruct average bounce/session for the window (per-page offsets)
    let b = 0, asv = 0;
    for (let i = cur[0]; i < cur[1]; i++) {
      b += STORE.days[i].bounce;
      asv += STORE.days[i].avgSession;
    }
    b /= n;
    asv /= n;
    const bounce = clamp(b + 0.09 * (h - 0.5) + (p.section === "sevai" ? -0.03 : p.section === "biz" ? 0.04 : 0), 0.18, 0.68);
    const avgTime = Math.round(clamp(asv * (0.78 + 0.55 * h2), 55, 900));

    return {
      id: p.id,
      title: p.title,
      path: p.path,
      section: p.section,
      views,
      delta: prevViews === 0 ? 0 : (views - prevViews) / prevViews,
      uniques,
      conv,
      convRate: views ? conv / views : 0,
      bounce,
      avgTime,
      spark: decimate(spark, 40),
    };
  });
}

export function getTopPages(range: RangeKey, segment: SegmentKey, count = 6): TableRow[] {
  return [...getRows(range, segment)].sort((a, b) => b.views - a.views).slice(0, count);
}

/* misc ----------------------------------------------------------------- */

export function getRangeLabel(range: RangeKey): string {
  const { cur } = windows(range);
  const a = STORE.days[cur[0]].date;
  const b = STORE.days[cur[1] - 1].date;
  const sameYear = a.getFullYear() === b.getFullYear();
  const sameMonth = sameYear && a.getMonth() === b.getMonth();
  const mo = (d: Date) => MONTHS[d.getMonth()];
  if (sameMonth) return `${mo(a)} ${a.getDate()} – ${b.getDate()}, ${b.getFullYear()}`;
  if (sameYear) return `${mo(a)} ${a.getDate()} – ${mo(b)} ${b.getDate()}, ${b.getFullYear()}`;
  return `${mo(a)} ${a.getDate()}, ${a.getFullYear()} – ${mo(b)} ${b.getDate()}, ${b.getFullYear()}`;
}

export function getLiveBase(segment: SegmentKey): number {
  return STORE.liveBase[segment];
}

function decimate(arr: number[], max: number): number[] {
  if (arr.length <= max) return arr;
  const step = Math.ceil(arr.length / max);
  const out: number[] = [];
  for (let i = 0; i < arr.length; i += step) out.push(arr[i]);
  if (out[out.length - 1] !== arr[arr.length - 1]) out.push(arr[arr.length - 1]);
  return out;
}

/* --------------------------- formatters ----------------------------- */

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const WDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

const compactFmt = new Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 1 });
const fullFmt = new Intl.NumberFormat("en-US");

export const fmtCompact = (n: number) => compactFmt.format(n);
export const fmtFull = (n: number) => fullFmt.format(n);

export const fmtPct = (x: number, digits = 2) => `${(x * 100).toFixed(digits)}%`;

export const fmtDelta = (x: number, digits = 1) => `${x >= 0 ? "+" : "−"}${Math.abs(x * 100).toFixed(digits)}%`;

export function fmtDur(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = Math.round(sec % 60);
  if (m <= 0) return `${s}s`;
  return `${m}m ${String(s).padStart(2, "0")}s`;
}

export function fmtTick(d: Date, range: RangeKey): string {
  if (range === "7d") return `${WDAYS[d.getDay()]} ${d.getDate()}`;
  if (range === "14d") return `${MONTHS[d.getMonth()]} ${d.getDate()}`;
  return `${MONTHS[d.getMonth()]} ${d.getDate()}`;
}

export function fmtTooltipDate(d: Date): string {
  return `${WDAYS[d.getDay()]}, ${MONTHS[d.getMonth()]} ${d.getDate()}`;
}

export function fmtKpiValue(value: number, format: KpiFormat): string {
  switch (format) {
    case "int":
      return fmtFull(Math.round(value));
    case "pct":
      return `${(value * 100).toFixed(2)}%`;
    case "dur":
      return fmtDur(value);
    case "num1":
      return value.toFixed(1);
  }
}
