import { useEffect, useRef, useState } from "react";
import { getLiveBase, type SegmentKey } from "./data";

/** Ease-out numeric tween — re-runs whenever `value` changes. */
export function useCountUp(value: number, duration = 850): number {
  const [display, setDisplay] = useState(value);
  const ref = useRef(value);

  useEffect(() => {
    const from = ref.current;
    const to = value;
    ref.current = value;
    if (from === to) {
      setDisplay(to);
      return;
    }
    let raf = 0;
    const start = performance.now();
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / duration);
      const e = 1 - Math.pow(1 - p, 3);
      setDisplay(from + (to - from) * e);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value, duration]);

  return display;
}

/** Simulated "people on the hub right now" ticker. */
export function useLiveCount(segment: SegmentKey): number {
  const [count, setCount] = useState(() => getLiveBase(segment));

  useEffect(() => {
    const base = getLiveBase(segment);
    setCount(base + Math.round(Math.random() * 4));
    const id = window.setInterval(() => {
      setCount((c) => {
        const next = c + Math.round(Math.random() * 7 - 3);
        return Math.max(Math.round(base * 0.55), Math.min(Math.round(base * 1.75), next));
      });
    }, 3200);
    return () => window.clearInterval(id);
  }, [segment]);

  return count;
}

/** Close handler for menus: outside pointer + Escape. */
export function useDismiss(ref: React.RefObject<HTMLElement | null>, onDismiss: () => void, active: boolean) {
  useEffect(() => {
    if (!active) return;
    const onDown = (e: PointerEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onDismiss();
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onDismiss();
    document.addEventListener("pointerdown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("pointerdown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [ref, onDismiss, active]);
}
